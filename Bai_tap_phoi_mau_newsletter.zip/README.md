# Bài tập: Phối màu cho newsletter

## Tệp bài làm
- `newsletter_version1.html`: bảng màu xanh ngọc, xanh đậm và san hô; phong cách tươi mới, thân thiện.
- `newsletter_version2.html`: bảng màu navy, tím và vàng; phong cách chuyên nghiệp, tập trung.

## Cách chạy
1. Tải cả hai file HTML về máy.
2. Mở từng file bằng Chrome hoặc Edge. Bootstrap được tải từ CDN nên cần kết nối Internet.
3. Có thể thay mã HEX trong phần `:root` ở đầu thẻ `<style>` để thử các palette khác.

## Bảng màu sử dụng
### Phiên bản 1
- Primary: `#087F8C`
- Secondary: `#0B3C49`
- Accent: `#FF7F6A`
- Nền: `#F1FAF9`

### Phiên bản 2
- Primary: `#25345C`
- Secondary: `#4E3A78`
- Accent: `#F4C95D`
- Nền: `#F4F3F9`

## Ghi chú Adobe Color
Đưa các màu HEX trên vào Adobe Color để lưu thành hai color theme và chụp ảnh màn hình làm minh chứng cho bước chọn palette. Hai bảng màu trong bài là phương án thực hành được chọn theo nguyên tắc phối màu; hãy lưu theme/chụp màn hình trong Adobe Color để có minh chứng sử dụng công cụ thực tế.
