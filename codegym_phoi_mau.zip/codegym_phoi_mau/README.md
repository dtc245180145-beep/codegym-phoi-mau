# Bài thực hành CodeGym: Sử dụng màu sắc trong trang web

## Nội dung
- `index.html`: trang minh họa phối màu đơn sắc theo tông xanh chủ đạo `#00ADEE`, có nền nội dung `#8DD7F7` và footer `#C6E9FA`.
- `palette-purple.html`: trang thứ hai dùng một bảng màu đơn sắc tông tím.

## Cách chạy
Mở `index.html` hoặc `palette-purple.html` bằng Chrome/Edge. Không cần cài đặt thêm thư viện.

## Lưu ý khi nộp
Trang `index.html` là bản minh họa được tạo mới theo yêu cầu màu sắc trong đề bài, không phải bản chỉnh sửa trực tiếp từ `Pra.zip` do chưa có file gốc trong cuộc trò chuyện. Để nộp đúng tuyệt đối phần 1, hãy đối chiếu hoặc thay phần giao diện mẫu của CodeGym bằng các màu tương ứng.
