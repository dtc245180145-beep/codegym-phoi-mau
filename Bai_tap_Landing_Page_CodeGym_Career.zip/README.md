# Landing Page CodeGym Career — Material Design

## Nội dung
- `index.html`: cấu trúc landing page, navbar responsive, hero, lợi ích, lộ trình, nội dung khóa học, CTA, form đăng ký minh họa và footer.
- `style.css`: màu sắc, card/shadow, bố cục responsive, hiệu ứng hover và giao diện Material-inspired.
- `script.js`: menu mobile, nút quay về đầu trang và kiểm tra form phía trình duyệt.

## Công nghệ
HTML5, CSS3, JavaScript, Bootstrap 4.5, MDBootstrap 4.19.1, jQuery, Popper.js, Font Awesome, Google Fonts Roboto.

## Chạy thử
Mở `index.html` bằng Chrome/Edge khi có Internet vì thư viện được tải qua CDN. Kiểm tra cả màn hình máy tính và điện thoại.

## Ghi chú
Đây là bài thực hành giao diện, tham khảo các nhóm nội dung trên https://codegym.vn/codegym-career/. Lộ trình, thời lượng, số liệu và hotline được dùng như nội dung minh họa; vui lòng đối chiếu trang nguồn trước khi sử dụng ngoài phạm vi bài tập. Form chỉ kiểm tra trên trình duyệt, không gửi hoặc lưu dữ liệu.

## Đưa lên GitHub
1. Tạo repository mới, ví dụ `codegym-career-landing-page`.
2. Upload `index.html`, `style.css`, `script.js`, `README.md`.
3. Commit changes.
4. Nếu muốn có link demo, vào Settings → Pages → Deploy from a branch → chọn `main` và `/root` → Save. Sau khi GitHub Pages triển khai xong, link sẽ có dạng `https://TEN-TAI-KHOAN.github.io/codegym-career-landing-page/`.
