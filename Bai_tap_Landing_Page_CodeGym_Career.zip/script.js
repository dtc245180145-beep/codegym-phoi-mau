$(function () {
  // Đóng menu sau khi chọn liên kết trên thiết bị di động.
  $('.navbar-nav a.nav-link, .navbar-nav a.btn').on('click', function () {
    $('.navbar-collapse').collapse('hide');
  });

  // Nút quay lại đầu trang.
  var $backToTop = $('#backToTop');
  $(window).on('scroll', function () {
    if ($(this).scrollTop() > 400) $backToTop.fadeIn(180);
    else $backToTop.fadeOut(180);
  });
  $backToTop.on('click', function () {
    $('html, body').animate({ scrollTop: 0 }, 450);
  });

  // Kiểm tra dữ liệu form phía trình duyệt; không gửi dữ liệu ra ngoài.
  $('#leadForm').on('submit', function (event) {
    event.preventDefault();
    var form = this;
    if (!form.checkValidity()) {
      event.stopPropagation();
      $(form).addClass('was-validated');
      $('#formMessage').removeClass('text-success').addClass('text-danger')
        .text('Vui lòng kiểm tra và điền đầy đủ các trường bắt buộc.');
      var firstInvalid = form.querySelector(':invalid');
      if (firstInvalid) firstInvalid.focus();
      return;
    }
    $(form).removeClass('was-validated');
    $('#formMessage').removeClass('text-danger').addClass('text-success')
      .text('Thông tin hợp lệ! Đây là bản demo, dữ liệu chưa được gửi đến máy chủ.');
    form.reset();
  });
});
